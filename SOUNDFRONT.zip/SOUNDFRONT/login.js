const loginForm = document.getElementById('loginForm');
const logoutBtn = document.getElementById('logoutBtn');

function checkSession() {
    const token = localStorage.getItem('token');
    if (token) {
        if (loginForm) loginForm.classList.add('hidden');
        if (logoutBtn) logoutBtn.classList.remove('hidden');
    } else {
        if (loginForm) loginForm.classList.remove('hidden');
        if (logoutBtn) logoutBtn.classList.add('hidden');
    }
}

checkSession();

if (loginForm) {
    loginForm.addEventListener('submit', async function (e) {
        e.preventDefault();

        const correo = document.getElementById('emailLogin').value.trim().toLowerCase();
        const clave = document.getElementById('passwordLogin').value;

        try {
            const response = await fetch('http://localhost:3000/api/usuarios/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ correo, clave })
            });

            const data = await response.json();

            if (response.ok && data.ok) {
                localStorage.setItem('token', data.token);
                localStorage.setItem('correo', data.usuario.correo);
                localStorage.setItem('rol', data.usuario.rol);

                window.location.href = data.usuario.rol === 'dueño' ? 'admin.html' : 'index.html';
            } else {
                alert(data.error || 'Usuario o contraseña incorrectos.');
            }
        } catch (error) {
            alert('Error al conectarse con el servidor.');
            console.error(error);
        }
    });
}

if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
        localStorage.clear();
        checkSession();
        window.location.href = 'login.html';
    });
}
