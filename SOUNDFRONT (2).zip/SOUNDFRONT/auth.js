// auth.js

export function saveToken(token) {
    localStorage.setItem('token', token);
    sessionStorage.setItem('token', token);
    console.log('Token guardado:', token);
}

export function getToken() {
    return sessionStorage.getItem('token') || localStorage.getItem('token');
}

export function clearToken() {
    localStorage.removeItem('token');
    sessionStorage.removeItem('token');
    localStorage.removeItem('rol');
    localStorage.removeItem('dni');
    localStorage.removeItem('correo');
    console.log('Tokens eliminados');
}

export function checkTokenExpiration() {
    const token = getToken();
    if (!token) return false;
    try {
        const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
        const now = Math.floor(Date.now() / 1000);
        if (payload.exp && payload.exp < now) {
            clearToken();
            alert('Tu sesión ha expirado. Por favor, inicia sesión de nuevo.');
            window.location.href = 'login.html';
            return true;
        }
    } catch (e) {
        clearToken();
        window.location.href = 'login.html';
        return true;
    }
    return false;
}
