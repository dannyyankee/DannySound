const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

loginForm.addEventListener('submit', async e => {
    e.preventDefault();
    clearErrors();

    const email = document.getElementById('emailLogin').value.trim();
    const password = document.getElementById('passwordLogin').value;

    if (!email) {
        showError('errorEmailLogin', 'El correo es obligatorio');
        return;
    }
    if (!password) {
        showError('errorPasswordLogin', 'La contraseña es obligatoria');
        return;
    }

    try {
        const res = await fetch('http://localhost:3000/usuarios/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ correo: email, clave: password })
        });

        if (!res.ok) {
            const error = await res.json();
            if (error && error.mensaje) {
                alert('Error: ' + error.mensaje);
            } else {
                alert('Error desconocido en login');
            }
            return;
        }

        const data = await res.json();

        // Guardar token y rol en localStorage
        localStorage.setItem('token', data.token);
        localStorage.setItem('rol', data.usuario.rol.toLowerCase());
        localStorage.setItem('correo', data.usuario.correo);

        // Redirigir según rol
        if (data.usuario.rol.toLowerCase() === 'cliente') {
            window.location.href = 'alquiler.html';
        } else if (data.usuario.rol.toLowerCase() === 'dueño' || data.usuario.rol.toLowerCase() === 'admin') {
            window.location.href = 'admin.html';
        } else {
            window.location.href = 'index.html';
        }

    } catch (err) {
        console.error('Error en login:', err);
        alert('Error en la conexión con el servidor');
    }
});

registerForm.addEventListener('submit', async e => {
    e.preventDefault();
    clearErrors();

    const dni = document.getElementById('dni').value.trim();
    const nombre = document.getElementById('name').value.trim();
    const apellidos = document.getElementById('lastName').value.trim();
    const correo = document.getElementById('emailRegister').value.trim();
    const clave = document.getElementById('passwordRegister').value;
    const clave2 = document.getElementById('password2Register').value;
    const rol = document.getElementById('rol').value;

    if (!dni) {
        showError('errorDni', 'El DNI es obligatorio');
        return;
    }
    if (!nombre) {
        showError('errorName', 'El nombre es obligatorio');
        return;
    }
    if (!apellidos) {
        showError('errorLastName', 'Los apellidos son obligatorios');
        return;
    }
    if (!correo) {
        showError('errorEmailRegister', 'El correo es obligatorio');
        return;
    }
    if (!clave) {
        showError('errorPasswordRegister', 'La contraseña es obligatoria');
        return;
    }
    if (clave !== clave2) {
        showError('errorPasswordRegister', 'Las contraseñas no coinciden');
        return;
    }
    if (!rol) {
        showError('errorRol', 'Selecciona un rol');
        return;
    }

    try {
        const res = await fetch('http://localhost:3000/usuarios', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                dni, nombre, apellidos, correo, clave, rol
            })
        });

        if (!res.ok) {
            const error = await res.json();
            if (error && error.mensaje) {
                alert('Error: ' + error.mensaje);
            } else {
                alert('Error desconocido en registro');
            }
            return;
        }

        alert('Registro exitoso. Ahora puedes iniciar sesión.');
        toggleForms();

    } catch (err) {
        console.error('Error en registro:', err);
        alert('Error en la conexión con el servidor');
    }
});

function clearErrors() {
    document.querySelectorAll('p[id^="error"]').forEach(p => p.textContent = '');
}

function showError(id, message) {
    const elem = document.getElementById(id);
    if (elem) elem.textContent = message;
}
