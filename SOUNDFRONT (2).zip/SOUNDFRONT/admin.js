// admin.js
import { getToken, clearToken } from './auth.js';

async function setupNav() {
    const token = getToken();
    const clienteLink = document.getElementById('clienteLink');
    const adminLink = document.getElementById('adminLink');
    const loginLink = document.getElementById('loginLink');
    const logoutLink = document.getElementById('logoutLink');
    const logoutBtn = document.getElementById('logoutBtn');

    if (!token) {
        clienteLink.classList.add('hidden');
        adminLink.classList.add('hidden');
        logoutLink.classList.add('hidden');
        loginLink.classList.remove('hidden');
        return;
    }

    try {
        const res = await fetch('http://localhost:3000/api/usuarios/me', {
            headers: { 'user-token': token }
        });
        if (!res.ok) throw new Error('No autorizado');
        const user = await res.json();
        const rol = (user.rol || '').toLowerCase();

        if (rol === 'cliente') {
            clienteLink.classList.remove('hidden');
            adminLink.classList.add('hidden');
        } else if (rol === 'dueño' || rol === 'admin') {
            adminLink.classList.remove('hidden');
            clienteLink.classList.add('hidden');
        } else {
            clienteLink.classList.add('hidden');
            adminLink.classList.add('hidden');
        }

        loginLink.classList.add('hidden');
        logoutLink.classList.remove('hidden');

        logoutBtn.addEventListener('click', () => {
            clearToken();
            window.location.href = 'login.html';
        });
    } catch {
        clearToken();
        clienteLink.classList.add('hidden');
        adminLink.classList.add('hidden');
        logoutLink.classList.add('hidden');
        loginLink.classList.remove('hidden');
    }
}

document.addEventListener('DOMContentLoaded', setupNav);
