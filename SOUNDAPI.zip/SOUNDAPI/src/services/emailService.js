const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
});

async function enviarCorreo(destinatario, asunto, texto) {
    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: destinatario,
        subject: asunto,
        text: texto,
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log('Correo enviado:', info.response);
        return info;
    } catch (error) {
        console.error('Error al enviar correo:', error);
        throw error;
    }
}

async function sendContactEmail({ nombre, apellido, email, asunto, mensaje }) {
    const texto = `
Nuevo mensaje de contacto desde DannySound:

Nombre: ${nombre} ${apellido}
Correo: ${email}
Asunto: ${asunto || '(sin asunto)'}
Mensaje:
${mensaje}
`;

    return await enviarCorreo(
        process.env.EMAIL_USER,
        `Nuevo mensaje de contacto: ${asunto || 'sin asunto'}`,
        texto
    );
}

module.exports = { enviarCorreo, sendContactEmail };
