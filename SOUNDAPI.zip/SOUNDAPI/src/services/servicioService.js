const { Servicio, Producto, DetalleServicio, Usuario } = require("../database/associations");

// Obtener todos los servicios con cliente y detalles
const getAllServicios = async () => {
    try {
        return await Servicio.findAll({
            include: [
                {
                    model: Usuario,
                    as: "cliente",
                    attributes: ["dni", "nombre", "correo"]
                },
                {
                    model: DetalleServicio,
                    as: "detalles",
                    include: {
                        model: Producto,
                        as: "producto"
                    }
                }
            ]
        });
    } catch (error) {
        console.error("Error obteniendo servicios:", error);
        throw error;
    }
};

// Obtener servicio por ID con cliente y detalles
const getServicioById = async (id) => {
    try {
        return await Servicio.findByPk(id, {
            include: [
                {
                    model: Usuario,
                    as: "cliente",
                    attributes: ["dni", "nombre", "correo"]
                },
                {
                    model: DetalleServicio,
                    as: "detalles",
                    include: {
                        model: Producto,
                        as: "producto"
                    }
                }
            ]
        });
    } catch (error) {
        console.error("Error obteniendo servicio:", error);
        throw error;
    }
};

// Crear servicio con productos alquilados
const crearServicioConProductos = async ({ dni_cliente, fecha_inicio, fecha_fin, productos }) => {
    try {
        const servicio = await Servicio.create({ dni_cliente, fecha_inicio, fecha_fin });

        const detalles = productos.map(p => ({
            id_servicio: servicio.id_servicio,
            id_producto: p.id_producto,
            precio_dia: p.precio_dia,
            dias: p.dias
        }));

        await DetalleServicio.bulkCreate(detalles);

        return servicio;
    } catch (error) {
        console.error("Error creando servicio con productos:", error);
        throw error;
    }
};

// Actualizar servicio
const actualizarServicio = async (data, id) => {
    try {
        const [updated] = await Servicio.update(data, { where: { id_servicio: id } });
        return updated;
    } catch (error) {
        console.error("Error actualizando servicio:", error);
        throw error;
    }
};

// Eliminar servicio
const eliminarServicio = async (id) => {
    try {
        return await Servicio.destroy({ where: { id_servicio: id } });
    } catch (error) {
        console.error("Error eliminando servicio:", error);
        throw error;
    }
};
const getServiciosDeCliente = async (dni_cliente) => {
    try {
        return await Servicio.findAll({
            where: { dni_cliente },
            include: [
                {
                    model: Usuario,
                    as: "cliente",
                    attributes: ["dni", "nombre", "correo"]
                },
                {
                    model: DetalleServicio,
                    as: "detalles",
                    include: {
                        model: Producto,
                        as: "producto"
                    }
                }
            ]
        });
    } catch (error) {
        console.error("Error obteniendo servicios del cliente:", error);
        throw error;
    }
};
module.exports = {
    getAllServicios,
    getServicioById,
    crearServicioConProductos,
    actualizarServicio,
    getServiciosDeCliente,
    eliminarServicio,
};
