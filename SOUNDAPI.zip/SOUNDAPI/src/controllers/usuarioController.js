const usuarioService = require("../services/usuarioService");

class UsuarioController {
  static async getUsers(req, res) {
    try {
      const rol = req.query.rol;
      const users = await usuarioService.getAllUsuarios(rol);
      res.status(200).json(users);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async login(req, res) {
    try {
      const result = await usuarioService.login(req);
      if (result.ok) {
        res.status(200).json(result);
      } else {
        res.status(401).json({ error: "Usuario o contraseña incorrectos" });
      }
    } catch (error) {
      console.error("Error en login:", error);
      res.status(500).json({ error: "Error interno del servidor" });
    }
  }

  static async getUnUsuarioCorreo(req, res) {
    try {
      const usuario = await usuarioService.getUnUsuarioCorreo(req.params.correo);
      if (usuario) {
        res.status(200).json(usuario);
      } else {
        res.status(404).json({ message: "Usuario no encontrado" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async register(req, res) {
    try {
      const usuario = await usuarioService.register(req.body);
      res.status(201).json({ message: "Usuario registrado correctamente", data: usuario });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async updateUsuario(req, res) {
    try {
      const updated = await usuarioService.updateUsuario(req.body, req.params.correo);
      if (updated) {
        res.status(200).json({ message: `Usuario ${req.params.correo} actualizado` });
      } else {
        res.status(404).json({ message: "Usuario no encontrado o sin cambios" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async remove(req, res) {
    try {
      const deleted = await usuarioService.remove(req.params.correo);
      if (deleted) {
        res.status(200).json({ message: "Usuario eliminado correctamente" });
      } else {
        res.status(404).json({ message: "Usuario no encontrado" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async me(req, res) {
    if (!req.user) {
      return res.status(401).json({ error: "No autenticado" });
    }
    try {
      const usuario = await usuarioService.getUnUsuarioPorDni(req.user.id);
      if (!usuario) return res.status(404).json({ error: "Usuario no encontrado" });
      res.json({
        dni: usuario.dni,
        correo: usuario.correo,
        rol: usuario.rol,
        nombre: usuario.nombre,
        apellidos: usuario.apellidos,
      });
    } catch (error) {
      res.status(500).json({ error: "Error interno al obtener usuario" });
    }
  }

  static async resetPassword(req, res) {
    const { correo } = req.body;
    if (!correo) return res.status(400).json({ mensaje: "Correo es obligatorio" });

    try {
      await usuarioService.recuperarPassword(correo);
      res.json({ mensaje: "Nueva contraseña enviada al correo" });
    } catch (error) {
      res.status(500).json({ mensaje: error.message || "Error al recuperar contraseña" });
    }
  }
}

module.exports = UsuarioController;
