const productoService = require("../services/productoService");

class ProductoController {
  static async listarProductos(req, res) {
    try {
      const productos = await productoService.getAllProductos();
      res.status(200).json(productos);
    } catch (error) {
      res.status(500).json({
        mensaje: "Error al obtener productos",
        error: error.message,
      });
    }
  }

  static async getProductoById(req, res) {
    try {
      const producto = await productoService.getProductoById(req.params.id);
      if (producto) {
        res.status(200).json(producto);
      } else {
        res.status(404).json({ mensaje: "Producto no encontrado" });
      }
    } catch (error) {
      res.status(500).json({ mensaje: "Error al obtener producto", error: error.message });
    }
  }

  static async crearProducto(req, res) {
    try {
      const nuevo = await productoService.crearProducto(req.body);
      res.status(201).json(nuevo);
    } catch (error) {
      res.status(500).json({ mensaje: "Error al crear producto", error: error.message });
    }
  }

  static async actualizarProducto(req, res) {
    try {
      const actualizado = await productoService.actualizarProducto(req.params.id, req.body);
      if (actualizado) {
        res.status(200).json({ mensaje: "Producto actualizado" });
      } else {
        res.status(404).json({ mensaje: "Producto no encontrado" });
      }
    } catch (error) {
      res.status(500).json({ mensaje: "Error al actualizar producto", error: error.message });
    }
  }

  static async eliminarProducto(req, res) {
    try {
      const eliminado = await productoService.eliminarProducto(req.params.id);
      if (eliminado) {
        res.status(200).json({ mensaje: "Producto eliminado" });
      } else {
        res.status(404).json({ mensaje: "Producto no encontrado" });
      }
    } catch (error) {
      res.status(500).json({ mensaje: "Error al eliminar producto", error: error.message });
    }
  }
}

module.exports = ProductoController;
