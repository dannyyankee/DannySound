const servicioService = require("../services/servicioService");

// GET /servicios → obtener todos los servicios
const getAllServicios = async (req, res) => {
  try {
    const servicios = await servicioService.getAllServicios();
    res.json(servicios);
  } catch (error) {
    console.error("Error al obtener servicios:", error);
    res.status(500).json({ error: "Error al obtener los servicios." });
  }
};

// GET /servicios/:id → obtener un servicio específico
const getServicioById = async (req, res) => {
  try {
    const servicio = await servicioService.getServicioById(req.params.id);
    if (!servicio) {
      return res.status(404).json({ error: "Servicio no encontrado." });
    }
    res.json(servicio);
  } catch (error) {
    console.error("Error al obtener servicio:", error);
    res.status(500).json({ error: "Error al obtener el servicio." });
  }
};

// POST /servicios → crear un nuevo servicio (con productos alquilados)
const crearServicioConProductos = async (req, res) => {
  try {
    const { dni_cliente, fecha_inicio, fecha_fin, productos } = req.body;

    if (!Array.isArray(productos) || productos.length === 0) {
      return res.status(400).json({ error: "Debes proporcionar productos para el servicio." });
    }

    const nuevoServicio = await servicioService.crearServicioConProductos({
      dni_cliente,
      fecha_inicio,
      fecha_fin,
      productos,
    });

    res.status(201).json({ ok: true, servicio: nuevoServicio });
  } catch (error) {
    console.error("Error al crear el servicio:", error);
    res.status(500).json({ error: "Error al crear el servicio." });
  }
};

// PUT /servicios/:id → actualizar un servicio
const actualizarServicio = async (req, res) => {
  try {
    const actualizado = await servicioService.actualizarServicio(req.body, req.params.id);
    if (!actualizado) {
      return res.status(404).json({ error: "Servicio no encontrado para actualizar." });
    }
    res.json({ ok: true });
  } catch (error) {
    console.error("Error al actualizar servicio:", error);
    res.status(500).json({ error: "Error al actualizar el servicio." });
  }
};

// DELETE /servicios/:id → eliminar un servicio
const eliminarServicio = async (req, res) => {
  try {
    const eliminado = await servicioService.eliminarServicio(req.params.id);
    if (!eliminado) {
      return res.status(404).json({ error: "Servicio no encontrado para eliminar." });
    }
    res.json({ ok: true });
  } catch (error) {
    console.error("Error al eliminar servicio:", error);
    res.status(500).json({ error: "Error al eliminar el servicio." });
  }
};
const getMisServicios = async (req, res) => {
  try {
    const dni_cliente = req.user.id; // el middleware pone el dni aquí
    const servicios = await servicioService.getServiciosDeCliente(dni_cliente);
    res.json(servicios);
  } catch (error) {
    console.error("Error al obtener mis servicios:", error);
    res.status(500).json({ error: "Error al obtener tus servicios." });
  }
};

module.exports = {
  getAllServicios,
  getServicioById,
  crearServicioConProductos,
  actualizarServicio,
  getMisServicios,
  eliminarServicio,
};
