const express = require("express");
const router = express.Router();
const {
    getAllServicios,
    getServicioById,
    crearServicioConProductos,
    actualizarServicio,
    eliminarServicio,
    getMisServicios // <-- Importamos el controlador de mis-servicios
} = require("../controllers/servicioController");
const { checkToken } = require("./middleware");

// Rutas públicas
router.get("/", getAllServicios);

// ⚠️ Ruta protegida para que el cliente vea solo SUS servicios
router.get("/mis-servicios", checkToken, getMisServicios);

// Rutas públicas (deben ir antes de las rutas por ID para evitar conflictos)
router.get("/:id", getServicioById);

// Rutas protegidas
router.post("/", checkToken, crearServicioConProductos);
router.put("/:id", checkToken, actualizarServicio);
router.delete("/:id", checkToken, eliminarServicio);

module.exports = router;
