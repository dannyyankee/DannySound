const { Servicio, Producto, DetalleServicio } = require("../database/associations");

// Obtener todos los servicios
const getAllServicios = async () => {
    try {
        return await Servicio.findAll({
            include: {
                model: DetalleServicio,
                as: "detalles",
                include: {
                    model: Producto,
                    as: "producto"
                }
            }
        });
    } catch (error) {
        console.error("Error obteniendo servicios:", error);
        throw error;
    }
};

// Obtener servicio por ID
const getServicioById = async (id) => {
    try {
        return await Servicio.findByPk(id, {
            include: {
                model: DetalleServicio,
                as: "detalles",
                include: {
                    model: Producto,
                    as: "producto"
                }
            }
        });
    } catch (error) {
        console.error("Error obteniendo servicio:", error);
        throw error;
    }
};

// Crear servicio con productos alquilados
const crearServicioConProductos = async ({ id_cliente, fecha_inicio, fecha_fin, productos }) => {
    try {
        const servicio = await Servicio.create({ id_cliente, fecha_inicio, fecha_fin });

        const detalles = productos.map(p => ({
            id_servicio: servicio.id_servicio,
            id_producto: p.id_producto,
            precio_dia: p.precio_dia,
            dias: p.dias
        }));

        await DetalleServicio.bulkCreate(detalles);

        return servicio;
    } catch (error) {
        console.error("Error creando servicio con productos:", error);
        throw error;
    }
};

// Actualizar servicio
const actualizarServicio = async (data, id) => {
    try {
        const [updated] = await Servicio.update(data, { where: { id_servicio: id } });
        return updated;
    } catch (error) {
        console.error("Error actualizando servicio:", error);
        throw error;
    }
};

// Eliminar servicio
const eliminarServicio = async (id) => {
    try {
        return await Servicio.destroy({ where: { id_servicio: id } });
    } catch (error) {
        console.error("Error eliminando servicio:", error);
        throw error;
    }
};

module.exports = {
    getAllServicios,
    getServicioById,
    crearServicioConProductos,
    actualizarServicio,
    eliminarServicio,
};
