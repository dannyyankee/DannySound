const Producto = require("../database/models/Producto");
const Usuario = require("../database/models/Usuario");
// Importar los modelos necesarios



// OBTENER TODOS LOS PRODUCTOS
const getAllProductos = async () => {
  try {
    return await Producto.findAll({
      include: {
        model: Usuario,
        as: "dueño",
        attributes: ["nombre", "correo"]
      }
    });
  } catch (error) {
    console.error("Error obteniendo productos:", error);
    throw error;
  }
};

// OBTENER PRODUCTO POR ID
const getProductoById = async (id) => {
  try {
    return await Producto.findOne({ where: { id_producto: id } });
  } catch (error) {
    console.error("Error obteniendo producto:", error);
    throw error;
  }
};

// CREAR PRODUCTO
const crearProducto = async (data) => {
  try {
    return await Producto.create(data);
  } catch (error) {
    console.error("Error creando producto:", error);
    throw error;
  }
};

// ACTUALIZAR PRODUCTO
const actualizarProducto = async (id, data) => {
  try {
    const [updated] = await Producto.update(data, { where: { id_producto: id } });
    return updated;
  } catch (error) {
    console.error("Error actualizando producto:", error);
    throw error;
  }
};

// ELIMINAR PRODUCTO
const eliminarProducto = async (id) => {
  try {
    return await Producto.destroy({ where: { id_producto: id } });
  } catch (error) {
    console.error("Error eliminando producto:", error);
    throw error;
  }
};

module.exports = {
  getAllProductos,
  getProductoById,
  crearProducto,
  actualizarProducto,
  eliminarProducto,
};
