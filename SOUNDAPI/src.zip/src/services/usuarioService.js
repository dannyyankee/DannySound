const Usuario = require("../database/models/Usuario");
const bcrypt = require("bcryptjs");
const moment = require("moment");
const jwt = require("jwt-simple");

const createToken = (usuario) => {
  const payload = {
    usuarioId: usuario.dni,
    createdAt: moment().unix(),
    expiredAt: moment().add(8, "hours").unix(),
  };
  return jwt.encode(payload, process.env.JWT_SECRET || "secret_key");
};

const login = async (req) => {
  try {
    const { correo, clave } = req.body;

    const usuario = await Usuario.findOne({ where: { correo } });
    if (!usuario) return { error: "Usuario o contraseña incorrectos" };

    const isValid = await bcrypt.compare(clave, usuario.clave);
    if (!isValid) return { error: "Usuario o contraseña incorrectos" };

    const token = createToken(usuario);
    return {
      ok: true,
      token,
      usuario: {
        dni: usuario.dni,
        correo: usuario.correo,
        rol: usuario.rol,
      },
    };
  } catch (error) {
    console.error("Error en login:", error);
    return { error: "Error interno en login" };
  }
};

const register = async (data) => {
  try {
    const hashedPassword = await bcrypt.hash(data.clave, 10);
    const nuevoUsuario = await Usuario.create({
      dni: data.dni,
      nombre: data.nombre,
      apellidos: data.apellidos,
      correo: data.correo,
      clave: hashedPassword,
      rol: data.rol || "cliente",
    });
    return nuevoUsuario;
  } catch (error) {
    console.error("Error registrando usuario:", error);
    throw error;
  }
};

const getAllUsuarios = async () => {
  return await Usuario.findAll();
};

const getUnUsuarioCorreo = async (correo) => {
  return await Usuario.findOne({ where: { correo } });
};

const updateUsuario = async (data, correo) => {
  const [updated] = await Usuario.update(data, { where: { correo } });
  return updated;
};

const remove = async (correo) => {
  const deleted = await Usuario.destroy({ where: { correo } });
  return deleted;
};

module.exports = {
  login,
  register,
  createToken,
  getAllUsuarios,
  getUnUsuarioCorreo,
  updateUsuario,
  remove,
};
