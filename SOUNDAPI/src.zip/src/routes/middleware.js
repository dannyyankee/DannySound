const jwt = require("jwt-simple");
const moment = require("moment");

const checkToken = (req, res, next) => {
  const token = req.headers["user-token"];

  if (!token) {
    return res.status(401).json({ error: "Falta Token" });
  }

  let payload = null;
  try {
    payload = jwt.decode(token, process.env.JWT_SECRET || "secret_key");
  } catch (error) {
    return res.status(401).json({ error: "Token incorrecto" });
  }

  if (payload.expiredAt < moment().unix()) {
    return res.status(401).json({ error: "El token ha expirado, debe volver a autenticarse" });
  }

  // Puedes guardar info del usuario en req si quieres, p.ej:
  req.user = {
    id: payload.usuarioId,
  };

  next();
};

module.exports = { checkToken };
