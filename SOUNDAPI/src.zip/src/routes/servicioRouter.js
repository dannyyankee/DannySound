const express = require('express');
const router = express.Router();
const servicioController = require('../controllers/servicioController');
const { checkToken } = require('../middleware'); // <- Ajustado

// Rutas protegidas por token
router.get('/', checkToken, servicioController.obtenerTodosLosServicios);
router.get('/:id', checkToken, servicioController.obtenerServicioPorId);
router.post('/', checkToken, servicioController.crearServicio);
router.put('/:id', checkToken, servicioController.actualizarServicio);
router.delete('/:id', checkToken, servicioController.eliminarServicio);

module.exports = router;
