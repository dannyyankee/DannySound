const express = require("express");
const UsuarioController = require("../controllers/UsuarioController");
const middleware = require("./middleware");

const router = express.Router();

router.get("/all", middleware.checkToken, UsuarioController.getUsers);
router.get("/:correo", UsuarioController.getUnUsuarioCorreo);
router.post("/register", UsuarioController.register);
router.post("/login", UsuarioController.login);
router.put("/modify/:correo", middleware.checkToken, UsuarioController.updateUsuario);
router.delete("/delete/:correo", middleware.checkToken, UsuarioController.remove);

module.exports = router;
