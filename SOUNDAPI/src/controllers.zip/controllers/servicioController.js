const servicioService = require("../services/servicioService");

class ServicioController {
  static async listarServicios(req, res) {
    try {
      const servicios = await servicioService.getAllServicios();
      res.status(200).json(servicios);
    } catch (error) {
      res.status(500).json({ mensaje: "Error al obtener servicios", error: error.message });
    }
  }

  static async getServicioById(req, res) {
    try {
      const servicio = await servicioService.getServicioById(req.params.id);
      if (servicio) {
        res.status(200).json(servicio);
      } else {
        res.status(404).json({ mensaje: "Servicio no encontrado" });
      }
    } catch (error) {
      res.status(500).json({ mensaje: "Error al obtener servicio", error: error.message });
    }
  }

  static async crearServicio(req, res) {
    try {
      const nuevoServicio = await servicioService.crearServicio(req.body);
      res.status(201).json(nuevoServicio);
    } catch (error) {
      res.status(500).json({ mensaje: "Error al crear servicio", error: error.message });
    }
  }

  static async actualizarServicio(req, res) {
    try {
      const actualizado = await servicioService.actualizarServicio(req.params.id, req.body);
      if (actualizado) {
        res.status(200).json({ mensaje: "Servicio actualizado correctamente" });
      } else {
        res.status(404).json({ mensaje: "Servicio no encontrado o no modificado" });
      }
    } catch (error) {
      res.status(500).json({ mensaje: "Error al actualizar servicio", error: error.message });
    }
  }

  static async eliminarServicio(req, res) {
    try {
      const eliminado = await servicioService.eliminarServicio(req.params.id);
      if (eliminado) {
        res.status(200).json({ mensaje: "Servicio eliminado correctamente" });
      } else {
        res.status(404).json({ mensaje: "Servicio no encontrado" });
      }
    } catch (error) {
      res.status(500).json({ mensaje: "Error al eliminar servicio", error: error.message });
    }
  }
}

module.exports = ServicioController;
