const usuarioService = require("../services/usuarioService");

class UsuarioController {
  static async getUsers(req, res) {
    try {
      const users = await usuarioService.getAllUsuarios();
      res.status(200).json(users);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async login(req, res) {
    try {
      const result = await usuarioService.login(req);
      if (result.ok) {
        // En result debe venir token y rol para distinguir la ruta frontend
        res.status(200).json(result);
      } else {
        res.status(401).json({ error: "Usuario o contraseña incorrectos" });
      }
    } catch (error) {
      console.error("Error en login:", error);
      res.status(500).json({ error: "Error interno del servidor" });
    }
  }

  static async getUnUsuarioCorreo(req, res) {
    try {
      const usuario = await usuarioService.getUnUsuarioCorreo(req.params.correo);
      usuario ? res.status(200).json(usuario) : res.status(404).json({ message: "Usuario no encontrado" });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async register(req, res) {
    try {
      const usuario = await usuarioService.register(req.body);
      res.status(201).json({ message: "Usuario registrado correctamente", data: usuario });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async updateUsuario(req, res) {
    try {
      const updatedUsuario = await usuarioService.updateUsuario(req.body, req.params.correo);
      updatedUsuario ? res.status(200).json({ message: `Usuario ${req.params.correo} actualizado` }) : res.status(404).json({ message: "Usuario no encontrado o sin cambios" });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async remove(req, res) {
    try {
      const deletedUsuario = await usuarioService.remove(req.params.correo);
      deletedUsuario ? res.status(200).json({ message: "Usuario eliminado correctamente" }) : res.status(404).json({ message: "Usuario no encontrado" });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = UsuarioController;
