const productoService = require("../services/productoService");

class ProductoController {
  static async listarProductos(req, res) {
    try {
      const productos = await productoService.getAllProductos();
      res.status(200).json(productos);
    } catch (error) {
      res.status(500).json({ mensaje: "Error al obtener productos", error: error.message });
    }
  }
}

module.exports = ProductoController;
