const express = require("express");
const ServicioController = require("../controllers/servicioController");
const middleware = require("../routes/middleware");

const router = express.Router();

router.get("/all", middleware.checkToken, ServicioController.listarServicios);
router.get("/:id", middleware.checkToken, ServicioController.getServicioById);
router.post("/create", middleware.checkToken, ServicioController.crearServicio);
router.put("/modify/:id", middleware.checkToken, ServicioController.actualizarServicio);
router.delete("/delete/:id", middleware.checkToken, ServicioController.eliminarServicio);

module.exports = router;
