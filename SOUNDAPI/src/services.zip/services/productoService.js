const Producto = require("../database/models/Producto");

// Obtener todos productos
const getAllProductos = async () => {
  return await Producto.findAll();
};

// Obtener por id
const getProductoById = async (id) => {
  return await Producto.findByPk(id);
};

// Crear producto
const crearProducto = async (data) => {
  return await Producto.create(data);
};

// Actualizar producto
const actualizarProducto = async (id, data) => {
  const [updated] = await Producto.update(data, { where: { id_producto: id } });
  return updated;
};

// Eliminar producto
const eliminarProducto = async (id) => {
  const deleted = await Producto.destroy({ where: { id_producto: id } });
  return deleted;
};

module.exports = {
  getAllProductos,
  getProductoById,
  crearProducto,
  actualizarProducto,
  eliminarProducto,
};
